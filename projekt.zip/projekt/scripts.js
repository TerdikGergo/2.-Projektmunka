let input = document.getElementById('input');
let submit = document.getElementById('submit');
let flexContainer = document.querySelector('.flex-container');

submit.addEventListener('click', function() {
    let newItem = document.createElement('div');
    newItem.classList.add('item');
    newItem.textContent = input.value;

    flexContainer.appendChild(newItem);
    input.value = '';
});